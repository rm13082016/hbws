def saturate(value, low, high):
    return max(low, min(value, high))