#!/usr/bin/env python3

from hb_common import ControllerBase, Params, State, ReferenceState, Command, saturate
import numpy as np

class Controller(ControllerBase):
    def init_control(self, param):
        self.km = param.km
        self.m1 = param.m1
        self.m2 = param.m2
        self.g = param.g
        self.l1 = param.l1
        self.l2 = param.l2
        self.lT = param.lT
        self.d = param.d
        self.J1z = param.J1z
        self.JT = (self.m1*self.l1**2+self.m2*self.l2**2+param.J2z+param.m3)*(param.l3x**2+param.l3y**2)
        self.Fe = (self.m1*self.l1*self.g+self.m2*self.l2*self.g)/self.lT
        
        #For Dirty Derivative#
        self.sig = 0.05
        self.dt = 0.01
        
        #Pitch#
        self.zetta_th = 0.7
        self.rise_time_th = 1.4
        self.wn_th = (0.5*3.1415)/(self.rise_time_th*(1-self.zetta_th**2)**0.5)
        self.Bth = self.lT/(self.m1*self.l1**2+self.m2*self.l2**2+param.J1y+param.J2y)       
        self.kd_th = 2*self.zetta_th*self.wn_th/self.Bth
        self.kp_th = (self.wn_th**2)/self.Bth
        self.theta = 0
        self.thetad = 0
        
        #Roll
        self.zetta_phi = 0.707
        self.rise_time_phi = 0.1
        self.wn_phi = (0.5*3.1415)/(self.rise_time_phi*(1-self.zetta_phi**2)**0.5)
        self.J1x = param.J1x
        self.kd_phi = self.J1x*2*self.zetta_phi*self.wn_phi
        self.kp_phi = self.J1x*self.wn_phi**2
        self.phi = 0
        self.phid = 0
        
        
        #Yaw
        self.zetta_psi = 0.707
        self.rise_time_psi = self.rise_time_phi * 10
        self.wn_psi = (0.5*3.1415)/(self.rise_time_psi*(1-self.zetta_psi**2)**0.5)
        self.Bpsi = (self.lT*self.Fe)/(self.JT + self.J1z)
        self.kd_psi = (2*self.zetta_psi*self.wn_psi)/(self.Bpsi)
        self.kp_psi = (self.wn_psi**2)/(self.Bpsi)
        self.psi = 0
        self.psid = 0

    pass

    def compute_control(self, param, state, reference, dt):
        self.dt = dt
    #compute theta and thetad at k
        self.thetad = ((2*self.sig-self.dt)/(2*self.sig+self.dt))*self.thetad+(2/(2*self.sig+self.dt))*(state.pitch - self.theta)
        self.theta = state.pitch
        
    #compute phi and phid at k
        self.phid = ((2*self.sig-self.dt)/(2*self.sig+self.dt))*self.phid+(2/(2*self.sig+self.dt))*(state.roll - self.phi)
        self.phi = state.roll
        
    #compute psi and psid at k
        self.psid = ((2*self.sig-self.dt)/(2*self.sig+self.dt))*self.psid+(2/(2*self.sig+self.dt))*(state.yaw - self.psi)
        self.psi = state.yaw
        
    #PD control
        self.Ffl = (self.m1*self.l1+self.m2*self.l2)*(self.g/self.lT)*np.cos(state.pitch)
        self.Ftheta = self.kp_th*(reference.pitch - self.theta)-self.kd_th*self.thetad
        self.roll_ref = self.kp_psi*(reference.yaw - self.psi)-self.kd_psi*self.psid
        self.Tphi = self.kp_phi*(self.roll_ref - self.phi)-self.kd_phi*self.phid

    #Set left and right and scale by km
        left = (1/(2*self.km))*(self.Ffl + self.Ftheta + self.Tphi/self.d)
        right = (1/(2*self.km))*(self.Ffl + self.Ftheta - self.Tphi/self.d)
    
        left = saturate(left, 0, 0.7)
        right = saturate(right, 0, 0.7)

        return Command(left=left, right=right)


if __name__ == '__main__':
    c = Controller()
    c._setup()
    c.run()

