#!/usr/bin/env python3

from hb_common import ControllerBase, Params, State, ReferenceState, Command, saturate
import numpy as np


class Controller(ControllerBase):
    def init_control(self, param):
	self.zetta = 0.707
	self.rise_time = 1.5       
	self.kd = (2*self.zetta*2.2)/(self.rise_time*param.Bth)
	self.kp = ((2.2/self.rise_time)**2)/param.Bth)
	self.sig = 0.05
	self.dt = 0.1
	self.theta_til_kmin1 = 0
	self.thetad_til_kmin1 = 0
	self.km = param.km
	self.m1 = param.m1
	self.m2 = param.m2
	self.g = param.g
	self.l1 = param.l1
	self.l2 = param.l2
	self.lT = param.lT
	

	pass

    def compute_control(self, param, state, reference, dt):
	
	#Compute Theta Dot Tilda at k #
	self.theta_til_k = self.state.pitch
	self.thetad_til_k = ((2*self.sig-self.dt)/(2*self.sig+self.dt))*self.thetad_til_kmin1+(2/(2*self.sig+self.dt))*(self.theta_til_k - self.theta_til_kmin1)
	
	#Update old Theta and Theta dot at k-1 #	
	self.theta_til_kmin1 = self.theta_til_k
	self.thetad_til_kmin1 = self.thetad_til_k
	
	#Find F tilda and F
	self.F_til = self.kp(self.theta_til_ref - self.theta_til) - self.kd*self.thetad_til
	self.Ffl = (self.m1*self.l1+self.m2*self.l2)*(self.g/self.lT)*np.cos(self.state.pitch)
	self.F = self.Ffl + self.F_til
	
	#scale by km	
	self.u = self.F/self.km

	#Set left and right	
	left = self.u/2
	right = self.u/2
	
        left = saturate(left, 0, 0.7)
        right = saturate(right, 0, 0.7)

        return Command(left=left, right=right)


if __name__ == '__main__':
    c = Controller()
    c._setup()
    c.run()

# theta_til_d = ((2*sig-dt)/(2*sig+dt))*theta_til[k-1] + (2/(2*sig+dt))*(theta_til[k]-theta_til[k-1]) #
# F_til = kp(theta_til_ref - theta_til) - kd*theta_til_d #
